﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E
{
    public class Usuarios
    {
        private string nomusuario;
        private string pass;
        private bool activo;

        public string NOMUSUARIO
        {
            get
            {
                return nomusuario;
            }

            set
            {
                nomusuario = value;
            }
        }
        public string PASS
        {
            get
            {
                return pass;
            }

            set
            {
                pass = value;
            }
        }
        public bool ACTIVO
        {
            get
            {
                return activo;
            }

            set
            {
                activo = value;
            }
        }

        public Usuarios()
        {
            nomusuario = String.Empty;
            pass = String.Empty;
            activo = true;
        }


    }
}
