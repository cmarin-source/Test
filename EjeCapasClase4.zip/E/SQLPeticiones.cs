﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace E
{
    public class SQLPeticiones
    {
        private string peticion;
        private List<SqlParameter> lstparametros;

        public SQLPeticiones()
        {
            this.peticion = String.Empty;
            this.lstparametros = new List<SqlParameter>();
        }

        public string PETICION
        {
            get
            {
                return peticion;
            }

            set
            {
                peticion = value;
            }
        }
        public List<SqlParameter> LSTPARAMETROS
        {
            get
            {
                return lstparametros;
            }

            set
            {
                lstparametros = value;
            }
        }
    }
}
