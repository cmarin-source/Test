﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E;
using LN;


namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int opc = 0;

                do{
                    Console.Clear();
                    Console.WriteLine("Menu principal");
                    Console.WriteLine("1. Insercion");
                    Console.WriteLine("2. Eliminacion");
                    Console.WriteLine("3. Modificacion");
                    Console.WriteLine("4. Listar");
                    Console.WriteLine("5. Salir");
                    opc = Convert.ToInt32(Console.ReadLine());

                    switch(opc)
                    {
                        case 1: {
                                Usuarios objusuario = new Usuarios();

                                Console.Clear();
                                Console.WriteLine("Digite usuario: ");
                                objusuario.NOMUSUARIO = Console.ReadLine();
                                Console.WriteLine("Digite pass: ");
                                objusuario.PASS = Console.ReadLine();
                                Console.WriteLine("Digite Estado(A/I): ");
                                string estado = Console.ReadLine();
                                if (estado.ToUpper().Equals("A"))
                                    objusuario.ACTIVO = true;
                                else
                                    objusuario.ACTIVO = false;

                                Logica.Agregar_Usuarios(objusuario);
                                Console.WriteLine("usuario agregado");
                                Console.ReadKey();
                            } break;
                        case 2:
                            {
                                Usuarios objusuario = new Usuarios();

                                Console.Clear();
                                Console.WriteLine("Digite usuario: ");
                                objusuario.NOMUSUARIO = Console.ReadLine();
                               
                                Logica.Eliminar_Usuarios(objusuario);
                                Console.WriteLine("usuario eliminado");
                                Console.ReadKey();
                            }
                            break;
                        case 3:
                            {
                                Usuarios objusuario = new Usuarios();

                                Console.Clear();
                                Console.WriteLine("Digite usuario: ");
                                objusuario.NOMUSUARIO = Console.ReadLine();
                                Console.WriteLine("Digite pass: ");
                                objusuario.PASS = Console.ReadLine();
                                Console.WriteLine("Digite Estado(A/I): ");
                                string estado = Console.ReadLine();
                                if (estado.ToUpper().Equals("A"))
                                    objusuario.ACTIVO = true;
                                else
                                    objusuario.ACTIVO = false;

                                Logica.Modificar_Usuarios(objusuario);
                                Console.WriteLine("usuario modificado");
                                Console.ReadKey();
                            }
                            break;
                        case 4: {
                                List<Usuarios> lstusuarios = Logica.Obtener_Usuarios();

                                Console.Clear();
                                foreach (Usuarios u in lstusuarios)
                                {
                                    Console.WriteLine("Usuario: " + u.NOMUSUARIO);
                                    Console.WriteLine("Password: " + u.PASS);
                                    if(u.ACTIVO)
                                        Console.WriteLine("Estado: ACTIVO");
                                    else
                                        Console.WriteLine("Estado: INACTIVO");
                                    Console.WriteLine("*****************************");
                                }
                                Console.ReadKey();
                            } break;
                    }
                } while (opc != 5);
            }
            catch(Exception ex)
            {
                Console.Clear();
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }
    }
}
