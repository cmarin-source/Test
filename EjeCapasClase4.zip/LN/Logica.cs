﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E;
using AD;

namespace LN
{
    public class Logica
    {
        /// <summary>
        /// Método para agregar usuario en base de datos
        /// </summary>
        /// <param name="usuario">Recibe un objeto usuario</param>
        /// <returns>Devuelve TRUE = Correcto | FALSE = Incorrecto</returns>
        public static bool Agregar_Usuarios(Usuarios usuario)
        {
            try
            {   //Se crea objeto para armado sentencia
                SQLPeticiones peticion = new SQLPeticiones();
                //Arma la sentencia con los datos del parametro entrada
                peticion.PETICION = @"exec pa_InsertarUsuario '" + usuario.NOMUSUARIO + "','" + usuario.PASS + "','" + usuario.ACTIVO + "'";
                //Se hace el llamado al ACCESO DATOS
                AccesoDatos objacceso = new AccesoDatos();
                objacceso.Ejecutar_Sentecias(peticion);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Método para modificar usuario en base de datos
        /// </summary>
        /// <param name="usuario">Recibe un objeto usuario</param>
        /// <returns>Devuelve TRUE = Correcto | FALSE = Incorrecto</returns>
        public static bool Modificar_Usuarios(Usuarios usuario)
        {
            try
            {   //Se crea objeto para armado sentencia
                SQLPeticiones peticion = new SQLPeticiones();
                //Arma la sentencia con los datos del parametro entrada
                peticion.PETICION = @"exec pa_ModificacionUsuario '" + usuario.NOMUSUARIO + "','" + usuario.PASS + "','" + usuario.ACTIVO + "'";
                //Se hace el llamado al ACCESO DATOS
                AccesoDatos objacceso = new AccesoDatos();
                objacceso.Ejecutar_Sentecias(peticion);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Método para eliminar usuario en base de datos
        /// </summary>
        /// <param name="usuario">Recibe un objeto usuario</param>
        /// <returns>Devuelve TRUE = Correcto | FALSE = Incorrecto</returns>
        public static bool Eliminar_Usuarios(Usuarios usuario)
        {
            try
            {   //Se crea objeto para armado sentencia
                SQLPeticiones peticion = new SQLPeticiones();
                //Arma la sentencia con los datos del parametro entrada
                peticion.PETICION = @"exec pa_EliminarUsuario '" + usuario.NOMUSUARIO + "'";
                //Se hace el llamado al ACCESO DATOS
                AccesoDatos objacceso = new AccesoDatos();
                objacceso.Ejecutar_Sentecias(peticion);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Método para obtener listado de usuarios de base de datos
        /// </summary>
        /// <param name="usuario">Recibe un objeto usuario</param>
        /// <returns>Devuelve resultado consulta (Lista usuarios)</returns>
        public static List<Usuarios> Obtener_Usuarios()
        {
            try
            {   //Se crea objeto para armado sentencia
                SQLPeticiones peticion = new SQLPeticiones();
                //Arma la sentencia con los datos del parametro entrada
                peticion.PETICION = @"SELECT nomusuario, pass, activo FROM Usuarios ";
           
                //Se hace el llamado al ACCESO DATOS
                AccesoDatos objacceso = new AccesoDatos();
                return objacceso.ObtenerUsuarios(peticion);                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
