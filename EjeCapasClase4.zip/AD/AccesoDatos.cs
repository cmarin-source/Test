﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E;
using System.Data.SqlClient; //PRoveedor de SQL - ADO.NET 
using System.Data;

namespace AD
{
    public class AccesoDatos
    {
        #region ATRIBUTOS
        private string cadenaconexion = Properties.Settings.Default.ConexionBD;
        private SqlConnection objconexion;
        #endregion

        #region CONSTRUCTOR
        public AccesoDatos()
        {
            try
            {
                objconexion = new SqlConnection(cadenaconexion);
                this.ABRIR();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                this.CERRAR();
            }
        }
        #endregion

        #region METODOS PRIVADOS
        private void ABRIR()
        {
            if (objconexion.State == System.Data.ConnectionState.Closed)
                objconexion.Open();
        }
        private void CERRAR()
        {
            if (objconexion.State == System.Data.ConnectionState.Open)
                objconexion.Close();
        }
        #endregion

        #region METODOS PUBLICOS

        public int Ejecutar_Sentecias(SQLPeticiones peticion)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();

                //configuracion
                cmd.Connection = objconexion;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = peticion.PETICION;

                this.ABRIR();
                cmd.ExecuteNonQuery(); //Ejecucion
                return 1;
            }
            catch (Exception ex)
            { 
                throw ex;
            }
            finally
            {
                this.CERRAR();
            }
        }

        public List<Usuarios> ObtenerUsuarios(SQLPeticiones peticion)
        {
            List<Usuarios> lstresultados = new List<Usuarios>();

            try
            {
                //EN CONSULTAS: 
                //Primera parte: el armado de la peticion a ejecutar

                //Se configura la peticion por ejecutar
                SqlCommand cmd = new SqlCommand();

                //configuracion
                cmd.Connection = objconexion;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = peticion.PETICION;

                //Segunda parte: Configuracion del objeto que recibe respuesta
                //y arma en memoria la informacion recibida                
                DataTable dt = new DataTable(); //Captura inicialmente resultado consultado

                //Esta instancia es la que se encarga de ejecutar en BD y 
                //retornar el resultado
                SqlDataAdapter objcarga = new SqlDataAdapter(cmd);
                objcarga.Fill(dt);

                foreach (DataRow fila in dt.Rows)
                {
                    Usuarios u = new Usuarios();

                    u.NOMUSUARIO = fila.ItemArray[0].ToString();
                    u.PASS = fila.ItemArray[1].ToString();
                    u.ACTIVO = Convert.ToBoolean(fila.ItemArray[2].ToString());
                    lstresultados.Add(u);
                }               
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                this.CERRAR();
            }

            return lstresultados;
        }

        #endregion
    }
}
